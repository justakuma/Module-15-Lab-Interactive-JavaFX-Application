package com.example.mycalc;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CalcusController {
    @FXML
    private Label resultLabel, expressionLabel;

    String currentText = "";
    Boolean isOperandSingle = Boolean.FALSE;

    @FXML
    protected void onZeroButtonClick() {
        currentText = resultLabel.getText();
        resultLabel.setText(currentText + "0");
    }

    @FXML
    protected void onOneButtonClick() {
        currentText = resultLabel.getText();
        resultLabel.setText(currentText + "1");
    }

    @FXML
    protected void onTwoButtonClick() {
        currentText = resultLabel.getText();
        resultLabel.setText(currentText + "2");
    }

    @FXML
    protected void onThreeButtonClick() {
        currentText = resultLabel.getText();
        resultLabel.setText(currentText + "3");
    }

    @FXML
    protected void onAddButtonClick() {
        currentText = resultLabel.getText();
        resultLabel.setText(currentText + "+");
    }

    @FXML
    protected void onSubtractButtonClick() {
        currentText = resultLabel.getText();
        resultLabel.setText(currentText + "-");
    }

    @FXML
    protected void onDotButtonClick() {
        currentText = resultLabel.getText();
        resultLabel.setText(currentText + ".");
    }

    @FXML
    protected void onBackspaceButtonClick() {
        currentText = resultLabel.getText();

        if (currentText != null && !currentText.isEmpty()) {
            // Remove the last character
            resultLabel.setText(currentText.substring(0, currentText.length() - 1));
        }
    }

    private Boolean expressionEvaluator(String expression){

        //String expressionRegEx = "\\d+\\s*[x*÷+-]\\s*\\d+";
        String expressionRegEx = "\\d*\\.?\\d+[+-]\\d*\\.?\\d+?|√\\d+";

        // Compile the regex into a Pattern object
        Pattern pattern = Pattern.compile(expressionRegEx);

        //System.out.println(expression);
        // Create a matcher for the expression string
        Matcher matcher = pattern.matcher(expression);

        if (matcher.matches())
        {
            return Boolean.TRUE;
        }

        return Boolean.FALSE;
    }

    @FXML
    protected void onEqualButtonClick() {
        String theExpression = resultLabel.getText();

        Boolean evaluationResult = expressionEvaluator(theExpression);

        if(evaluationResult) {
            expressionLabel.setText(theExpression);
            String result = doTheMath(theExpression);
            resultLabel.setText(result);
        }else{
            resultLabel.setText("Wrong expression");
        }
    }

    private String doTheMath (String expression)
    {
        //expression: 3 + 4
        char theOperator = ' ';
        String[] parts = expression.split("[\\+\\-x÷%%!√]");

        if (expression.contains("+"))
        {
            theOperator = '+';
        }else if (expression.contains("-"))
        {
            theOperator = '-';
        }else{ //when no operator is found
            resultLabel.setText(resultLabel.getText());
        }

        //cast the String into Integer
        double operand1 = 0;
        double operand2 = 0;
        double operand3 = 0;

        if (!isOperandSingle) {
            operand1 = Double.parseDouble(parts[0]);
            operand2 = Double.parseDouble(parts[1]);
        }else{
            operand3 = (theOperator == '!') ? Double.parseDouble(parts[0]) : Double.parseDouble(parts[1]);
        }

        //perform th operation based on the operator
        double result = 0;

        switch (theOperator)
        {
            //multiple operands are handled below
            case '+':
                result = operand1 + operand2;
                break;
            case '-':
                result = operand1 - operand2;
                break;

            //single operands are handled below
            case '√':
                //System.out.println(operand3);
                result = Math.sqrt(operand3);
                isOperandSingle = Boolean.FALSE;
                break;
        }

        return String.valueOf(result);
    }

}