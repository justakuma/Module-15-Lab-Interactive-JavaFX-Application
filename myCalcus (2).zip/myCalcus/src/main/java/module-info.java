module com.example.mycalcus {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.mycalcus to javafx.fxml;
    exports com.example.mycalcus;
}