package com.example.mycalcus;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CalcusController {

    @FXML
    private Label resultLabel, expressionLabel;

    String currentText = "";
    Boolean isOperandSingle = Boolean.FALSE;

    @FXML
    protected void onZeroButtonClick() {
        resultLabel.setText(resultLabel.getText() + "0");
    }

    @FXML
    protected void onOneButtonClick() {
        resultLabel.setText(resultLabel.getText() + "1");
    }

    @FXML
    protected void onTwoButtonClick() {
        resultLabel.setText(resultLabel.getText() + "2");
    }

    @FXML
    protected void onThreeButtonClick() {
        resultLabel.setText(resultLabel.getText() + "3");
    }

    @FXML
    protected void onFourButtonClick() {
        resultLabel.setText(resultLabel.getText() + "4");
    }

    @FXML
    protected void onFiveButtonClick() {
        resultLabel.setText(resultLabel.getText() + "5");
    }

    @FXML
    protected void onSixButtonClick() {
        resultLabel.setText(resultLabel.getText() + "6");
    }

    @FXML
    protected void onSevenButtonClick() {
        resultLabel.setText(resultLabel.getText() + "7");
    }

    @FXML
    protected void onEightButtonClick() {
        resultLabel.setText(resultLabel.getText() + "8");
    }

    @FXML
    protected void onNineButtonClick() {
        resultLabel.setText(resultLabel.getText() + "9");
    }

    @FXML
    protected void onAddButtonClick() {
        resultLabel.setText(resultLabel.getText() + "+");
    }

    @FXML
    protected void onSubtractButtonClick() {
        resultLabel.setText(resultLabel.getText() + "-");
    }

    @FXML
    protected void onMultiplyButtonClick() {
        resultLabel.setText(resultLabel.getText() + "x");
    }

    @FXML
    protected void onDivideButtonClick() {
        resultLabel.setText(resultLabel.getText() + "÷");
    }

    @FXML
    protected void onDotButtonClick() {
        resultLabel.setText(resultLabel.getText() + ".");
    }

    @FXML
    protected void onBackspaceButtonClick() {
        String text = resultLabel.getText();
        if (text != null && !text.isEmpty()) {
            resultLabel.setText(text.substring(0, text.length() - 1));
        }
    }

    @FXML
    protected void onSqrtButtonClick() {
        resultLabel.setText("√" + resultLabel.getText());
    }

    @FXML
    protected void onClearButtonClick() {
        resultLabel.setText("");
        expressionLabel.setText("");
        isOperandSingle = false;
    }

    @FXML
    protected void onPercentButtonClick() {
        resultLabel.setText(resultLabel.getText() + "%");
    }

    @FXML
    protected void onReciprocalButtonClick() {
        resultLabel.setText("1/" + resultLabel.getText());
    }

    @FXML
    protected void onFactorialButtonClick() {
        resultLabel.setText(resultLabel.getText() + "!");
    }

    private Boolean expressionEvaluator(String expression) {
        String expressionRegEx =
                "\\d*\\.?\\d+([+\\-x÷%]\\d*\\.?\\d+)?|√\\d+|\\d+!|1/\\d*\\.?\\d+";

        Pattern pattern = Pattern.compile(expressionRegEx);
        Matcher matcher = pattern.matcher(expression);

        return matcher.matches();
    }

    @FXML
    protected void onEqualButtonClick() {
        String expression = resultLabel.getText();

        if (expressionEvaluator(expression)) {
            expressionLabel.setText(expression);
            resultLabel.setText(doTheMath(expression));
        } else {
            resultLabel.setText("Wrong expression");
        }
    }

    private String doTheMath(String expression) {

        if (expression.startsWith("1/")) {
            double value = Double.parseDouble(expression.substring(2));
            return String.valueOf(1 / value);
        }

        if (expression.startsWith("√")) {
            double value = Double.parseDouble(expression.substring(1));
            return String.valueOf(Math.sqrt(value));
        }

        if (expression.contains("!")) {
            double value = Double.parseDouble(expression.replace("!", ""));
            return String.valueOf(factorial((int) value));
        }

        char op = ' ';
        String[] parts = expression.split("[+\\-x÷%]");

        if (expression.contains("+")) op = '+';
        else if (expression.contains("-")) op = '-';
        else if (expression.contains("x")) op = 'x';
        else if (expression.contains("÷")) op = '÷';
        else if (expression.contains("%")) op = '%';

        double a = Double.parseDouble(parts[0]);
        double b = Double.parseDouble(parts[1]);

        switch (op) {
            case '+': return String.valueOf(a + b);
            case '-': return String.valueOf(a - b);
            case 'x': return String.valueOf(a * b);
            case '÷': return String.valueOf(a / b);
            case '%': return String.valueOf(a % b);
        }

        return "Wrong expression";
    }

    private int factorial(int n) {
        int result = 1;
        for (int i = 1; i <= n; i++) {
            result *= i;
        }
        return result;
    }
}